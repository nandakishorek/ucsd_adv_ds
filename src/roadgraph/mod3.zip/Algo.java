package roadgraph;

enum Algo {
    DIJKSTRA,
    ASTAR
}
